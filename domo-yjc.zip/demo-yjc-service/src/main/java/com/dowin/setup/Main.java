package com.dowin.setup;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
@EnableJpaAuditing
public class Main {
	
	private static final Logger logger = LoggerFactory.getLogger(Main.class);

	private static volatile boolean running = true;

	@SuppressWarnings({"unused", "resource"})
	
    public static void main(String[] args) {
		try {
		
		synchronized (Main.class) {
			while (running) {
				try {
					long startTime = System.currentTimeMillis();
					logger.info("Dowin HBX Service starting...");
					String[] config = new String[] { "application-context.xml", "application-dubbo.xml" };
					ApplicationContext context = new ClassPathXmlApplicationContext(config);
					
					long endTime = System.currentTimeMillis();
						logger.info("Demo Service started on " + (endTime - startTime) / 1000);
					Main.class.wait();
				} catch (Throwable e) {
					e.printStackTrace();
					logger.error(e.getMessage(), e);
					System.exit(1);
				}
			}
		}
		} catch (IOException e) {
			logger.error(e);
		}
	}

}
