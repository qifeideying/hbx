/**
 * ProductFactorRepository.java 2019年4月18日
 */
package com.dowin.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

/**
 * <p>
 * <b>ProductFactorRepository</b> is
 * </p>
 *
 * @since 2019年5月18日
 * @author yangjc
 * @version $Id$
 */
public interface ProductFactorRepository extends JpaRepository<ProductFactor, Integer>,
JpaSpecificationExecutor<ProductFactor>{

	@Query("from ProductFactor where productId = ?1 order by seqNo")
	public List<ProductFactor> findByProductId(String productId);

	@Query("from ProductFactor where productId = ?1 and isDisplay =?2 order by seqNo")
	public List<ProductFactor> findByParams(String productId, int isDisplay);

}
