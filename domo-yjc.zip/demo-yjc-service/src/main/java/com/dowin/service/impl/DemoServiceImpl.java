/**
 * DemoServiceImpl.java 2019年5月13日
 */
package com.dowin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dowin.dao.ProductFactorRepository;

/**
 * <p>
 * <b>DemoServiceImpl</b> is
 * </p>
 *
 * @since 2019年5月13日
 * @author yangjc
 * @version $Id$
 */
@Service("demoService")
public class DemoServiceImpl implements IdemoService {

	@Autowired
	private ProductFactorRepository productFactorRepository;

	@Override
	public String sayHi(String name) {
		String productId = "";
		productFactorRepository.findByProductId(productId);
		return name + "你好";
	}
}
