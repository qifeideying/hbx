package com.dowin.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hbx_product_factor_options")
public class ProductFactorOptions implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9085427192204277280L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "FACTOR_ID")
	private Integer factorId;

	@Column(name = "PRODUCT_ID")//产品Id
	private String productId;
	
	@Column(name = "FACTOR_NAME")//因子名称
	private String factorName;
	
	@Column(name = "FACTOR_KEY")
	private String factorKey;

	@Column(name = "FACTOR_VALUE")//因子名称
	private String factorValue;
	
	@Column(name = "SEQ_NO")//序列号
	private Integer seqNo;
	
	@Column(name = "ADD_TIME")//添加时间
	private Date addTime;

	/**
	 * 
	 */
	public ProductFactorOptions() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the factorId
	 */
	public Integer getFactorId() {
		return factorId;
	}

	/**
	 * @param factorId the factorId to set
	 */
	public void setFactorId(Integer factorId) {
		this.factorId = factorId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getFactorName() {
		return factorName;
	}

	public void setFactorName(String factorName) {
		this.factorName = factorName;
	}

	/**
	 * @return the factorKey
	 */
	public String getFactorKey() {
		return factorKey;
	}

	/**
	 * @param factorKey the factorKey to set
	 */
	public void setFactorKey(String factorKey) {
		this.factorKey = factorKey;
	}

	public String getFactorValue() {
		return factorValue;
	}

	public void setFactorValue(String factorValue) {
		this.factorValue = factorValue;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Date getAddTime() {
		return addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	
}