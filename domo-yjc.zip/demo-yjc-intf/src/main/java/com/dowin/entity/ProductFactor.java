package com.dowin.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="hbx_product_factor")
public class ProductFactor implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 5179185030898383213L;

	@Id
	@Column(name = "FACTOR_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer factorId;
	
	@Column(name = "ACTIVE")
	private Integer active;//是否有效。1：有效，0，删除

	@Column(name = "IS_DISPLAY")
	private Integer isDisplay;//是否显示。1：显示，0，不显示

	@Column(name = "PRODUCT_ID")//产品Id
	private String productId;
	
	@Column(name = "FACTOR_ITEM")//因子名称
	private String factorItem;
	
	//因子名称
	@Column(name = "FACTOR_KEY")
	private String factorKey;

	@Column(name = "FACTOR_TYPE")//因子类型：radio，checkbox，number，input
	private String factorType;
	
	@Column(name = "FACTOR_DEFAULT")//默认因子
	private String factorDefault;
	
	@Column(name = "SEQ_NO")//序列号
	private Integer seqNo;
	
	@Column(name = "ADD_TIME")//添加时间
	private Date addTime;

	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name = "FACTOR_ID")
	@NotFound(action = NotFoundAction.IGNORE)
	private List<ProductFactorOptions> factorOptions = new ArrayList<ProductFactorOptions>();//选项

	/**
	 * 
	 */
	public ProductFactor() {
		super();
	}

	/**
	 * @return the factorId
	 */
	public Integer getFactorId() {
		return factorId;
	}

	/**
	 * @param factorId the factorId to set
	 */
	public void setFactorId(Integer factorId) {
		this.factorId = factorId;
	}

	/**
	 * @return the factorOptions
	 */
	public List<ProductFactorOptions> getFactorOptions() {
		return factorOptions;
	}

	/**
	 * @param factorOptions the factorOptions to set
	 */
	public void setFactorOptions(List<ProductFactorOptions> factorOptions) {
		this.factorOptions = factorOptions;
	}


	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getFactorItem() {
		return factorItem;
	}

	public void setFactorItem(String factorItem) {
		this.factorItem = factorItem;
	}

	public String getFactorType() {
		return factorType;
	}

	public void setFactorType(String factorType) {
		this.factorType = factorType;
	}

	public String getFactorDefault() {
		return factorDefault;
	}

	public void setFactorDefault(String factorDefault) {
		this.factorDefault = factorDefault;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Date getAddTime() {
		return addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}

	/**
	 * @return the factorKey
	 */
	public String getFactorKey() {
		return factorKey;
	}

	/**
	 * @param factorKey the factorKey to set
	 */
	public void setFactorKey(String factorKey) {
		this.factorKey = factorKey;
	}

	/**
	 * @return the active
	 */
	public Integer getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(Integer active) {
		this.active = active;
	}

	/**
	 * @return the isDisplay
	 */
	public Integer getIsDisplay() {
		return isDisplay;
	}

	/**
	 * @param isDisplay the isDisplay to set
	 */
	public void setIsDisplay(Integer isDisplay) {
		this.isDisplay = isDisplay;
	}
	
}