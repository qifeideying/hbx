package com.dowin.util;

public class Constant {
  
	public static final String CHARACTER_ENCODE = "UTF-8";

	// 登录用户SESSION
	public static final String LOGIN_USER = "LOGIN_USER";

	// 渠道SESSION
	public static final String LOGIN_ORGANIZATION = "LOGIN_ORGANIZATION";

	// 来源  PC或者移动
	public static final String ISPC = "ISPC";

	// 当前使用的语言
	public static final String CURRENT_LANGUAGE = "CURRENT_LANGUAGE";

	// 列表每页显示的数量
	public static final int LIST_PAGE_SIZE = 15;


	// 返回结果提示语句
	public static final String RESULT_VALIDAE = "参数格式不对";
	public static final String RESULT_SUCCESS = "操作成功";
	public static final String RESULT_ERROR = "操作失败";
	public static final String RESULT_PERMISSION = "无效凭证";
	public static final String RESULT_LOSSEN = "数据签名错误";

	// 返回结果状态编码
	public static final int RESULT_CODE_VALIDAE = 401;
	public static final int RESULT_CODE_SUCCESS = 200;
	public static final int RESULT_CODE_BIZERROR = 203;
	public static final int RESULT_CODE_EXCEPTION = 500;
	public static final int RESULT_CODE_PERMISSION = 403;
	public static final int RESULT_CODE_LOSSEN = -1;

}
