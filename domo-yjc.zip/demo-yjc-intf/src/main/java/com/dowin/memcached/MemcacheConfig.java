package com.dowin.memcached;

public class MemcacheConfig implements java.io.Serializable {
	
	private static final long serialVersionUID = -7780282636551410827L;

	private String serverAddr;
	
	private String weights;
	
	private String initconn;
	
	private String minconn;
	
	private String maxconn;
	
	private String maxidle;
	
	private String maintsleep;
	
	private String nagle;
	
	private String socketTO;
	
	private String socketConnectTO;
	
	public MemcacheConfig(){}

	public String getMaxidle() {
		return maxidle;
	}

	public void setMaxidle(String maxidle) {
		this.maxidle = maxidle;
	}
	
	public String getServerAddr() {
		return serverAddr;
	}

	public void setServerAddr(String serverAddr) {
		this.serverAddr = serverAddr;
	}

	public String getWeights() {
		return weights;
	}

	public void setWeights(String weights) {
		this.weights = weights;
	}

	public String getInitconn() {
		return initconn;
	}

	public void setInitconn(String initconn) {
		this.initconn = initconn;
	}

	public String getMinconn() {
		return minconn;
	}

	public void setMinconn(String minconn) {
		this.minconn = minconn;
	}

	public String getMaxconn() {
		return maxconn;
	}

	public void setMaxconn(String maxconn) {
		this.maxconn = maxconn;
	}

	public String getMaintsleep() {
		return maintsleep;
	}

	public void setMaintsleep(String maintsleep) {
		this.maintsleep = maintsleep;
	}

	public String getNagle() {
		return nagle;
	}

	public void setNagle(String nagle) {
		this.nagle = nagle;
	}

	public String getSocketTO() {
		return socketTO;
	}

	public void setSocketTO(String socketTO) {
		this.socketTO = socketTO;
	}

	public String getSocketConnectTO() {
		return socketConnectTO;
	}

	public void setSocketConnectTO(String socketConnectTO) {
		this.socketConnectTO = socketConnectTO;
	}

}
