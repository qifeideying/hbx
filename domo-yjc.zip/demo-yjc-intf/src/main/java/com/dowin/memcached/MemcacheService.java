package com.dowin.memcached;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.danga.MemCached.MemCachedClient;
import com.danga.MemCached.SockIOPool;

@Service
public class MemcacheService {

	final Logger logger = LoggerFactory.getLogger(MemcacheService.class);

	private MemCachedClient mcc = null;
	
	/**
	 * 构造函数
	 * 
	 * @param serverAddr
	 *            服务器地址
	 */
	@Autowired
	public MemcacheService(MemcacheConfig memcacheConfig) {
		logger.info("初始化 MemcacheService .......");
		logger.info("ServerAddr : " + memcacheConfig.getServerAddr());
		logger.info("weights    : " + memcacheConfig.getWeights());
		logger.info("InitConn   : " + memcacheConfig.getInitconn());
		logger.info("MinConn    : " + memcacheConfig.getMinconn());
		logger.info("MaxConn    : " + memcacheConfig.getMaxconn());
		logger.info("MaxIdle    : " + memcacheConfig.getMaxidle());
		logger.info("Nagle      : " + memcacheConfig.getNagle());
		logger.info("SocketTO   : " + memcacheConfig.getSocketTO());
		logger.info("SocketConnectTO   : " + memcacheConfig.getSocketConnectTO());

		mcc = new MemCachedClient();
		Boolean nagle = false;

		// 获取socke连接池的实例对象
		SockIOPool pool = SockIOPool.getInstance();

		// 设置服务器信息
		pool.setServers(memcacheConfig.getServerAddr().split(";"));
		String[] weights = memcacheConfig.getWeights().split(";");
		Integer[] wei = new Integer[weights.length];
		for (int i = 0; i < weights.length; i++) {
			wei[i] = Integer.parseInt(weights[i]);
		}
		pool.setWeights(wei);

		// 设置初始连接数、最小和最大连接数以及最大处理时间
		pool.setInitConn(Integer.parseInt(memcacheConfig.getInitconn()));
		pool.setMinConn(Integer.parseInt(memcacheConfig.getMinconn()));
		pool.setMaxConn(Integer.parseInt(memcacheConfig.getMaxconn()));
		pool.setMaxIdle(Long.parseLong(memcacheConfig.getMaxidle()));

		// 设置主线程的睡眠时间
		pool.setMaintSleep(Long.parseLong(memcacheConfig.getMaintsleep()));
		if (!memcacheConfig.getNagle().equals("false")) {
			nagle = true;
		}

		// 设置TCP的参数，连接超时等
		pool.setNagle(nagle);
		pool.setSocketTO(Integer.parseInt(memcacheConfig.getSocketTO()));
		pool.setSocketConnectTO(Integer.parseInt(memcacheConfig.getSocketConnectTO()));

		// 初始化连接池
		pool.initialize();

		logger.info("Init complete ......");
	}

	// 在memcache中对数据进行存、取、删、更新
	public boolean set(String key, Object value) {
		return mcc.set(key, value);
	}

	/**
	 * 将对象添加至缓存
	 * @param key 缓存的Key
	 * @param value 缓存的对象
	 * @param time 缓存时间（毫秒数）
	 * @return
	 */
	public boolean set(String key, Object value, long times) {
		return mcc.set(key, value, new Date(times));
	}

	public Object get(String key) {
		return mcc.get(key);
	}

	public boolean delete(String key) {
		return mcc.delete(key);
	}

	public boolean update(String key, Object obj) {
		return mcc.replace(key, obj);
	}

	public boolean update(String key, Object value, Date expiry) {
		return mcc.replace(key, value, expiry);
	}

	public void flushAll() {
		mcc.flushAll();
	}

	public MemCachedClient getMcc() {
		return mcc;
	}

	public void setMcc(MemCachedClient mcc) {
		this.mcc = mcc;
	}

}
