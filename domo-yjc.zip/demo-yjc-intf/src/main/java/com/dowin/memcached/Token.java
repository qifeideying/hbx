/**
 * Token.java 2018年1月4日
 */
package com.dowin.memcached;

import java.io.Serializable;

/**
 * <p>
 * <b>Token</b> is
 * </p>
 *
 * @since 2018年7月12日
 * @author yangjc
 * @version $Id$
 */
public class Token implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8606407941027583251L;

	String userId;//渠道userId
	String channelId;//渠道Id
	String password;//渠道密码

	String mobile;//渠道用户mobile
	String extendInfo;//扩展信息
	
	String hidenav = "1";//为1 隐藏cps头部，0为不隐藏，不传默认为1

	String productId;//产品ID 必填
	
	String openId;//openId
	
	String bizContent; //业务定制参数，加密后的字符串包含了商业定制的业务信息，会在后续的Notify中回调给商户。注意：加密后长度不能超过2048字节
	/**
	 * 
	 */
	public Token() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param userId
	 * @param channelId
	 */
	public Token(String userId, String channelId) {
		super();
		this.userId = userId;
		this.channelId = channelId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the extendInfo
	 */
	public String getExtendInfo() {
		return extendInfo;
	}

	/**
	 * @param extendInfo the extendInfo to set
	 */
	public void setExtendInfo(String extendInfo) {
		this.extendInfo = extendInfo;
	}

	public String getHidenav() {
		return hidenav;
	}

	public void setHidenav(String hidenav) {
		this.hidenav = hidenav;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getBizContent() {
		return bizContent;
	}

	public void setBizContent(String bizContent) {
		this.bizContent = bizContent;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	
}
