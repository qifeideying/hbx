/**
 * IdemoService.java 2019年5月13日
 */
package com.dowin.service;

/**
 * <p>
 * <b>IdemoService</b> is
 * </p>
 *
 * @since 2019年5月13日
 * @author yangjc
 * @version $Id$
 */
public interface IdemoService {

	public String sayHi(String name);
}
