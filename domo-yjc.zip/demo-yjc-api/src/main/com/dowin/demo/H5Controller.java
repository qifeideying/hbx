/**
 * H5Controller.java 2018年7月10日
 */
package com.dowin.demo;

import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.dowin.hbx.entity.bastic.ServiceResult;
import com.dowin.hbx.entity.order.Order;
import com.dowin.hbx.entity.order.PolicyInsured;
import com.dowin.hbx.entity.organization.Organization;
import com.dowin.hbx.entity.organization.OrganizationProduct;
import com.dowin.hbx.entity.product.Product;
import com.dowin.hbx.framework.beans.ResultObject;
import com.dowin.hbx.framework.emun.OrderStatusEnum;
import com.dowin.hbx.framework.memcached.MemcacheService;
import com.dowin.hbx.framework.memcached.Token;
import com.dowin.hbx.framework.util.Constant;
import com.dowin.hbx.framework.util.RC4Util;
import com.dowin.hbx.framework.util.ResponseResultUtil;
import com.dowin.hbx.framework.util.ResponseUtil;
import com.dowin.hbx.framework.util.SessionUtil;
import com.dowin.hbx.framework.utils.UuidUtils;
import com.dowin.hbx.service.intf.order.IBaseOrderService;
import com.dowin.hbx.service.intf.organization.IOrganizationService;
import com.dowin.hbx.service.intf.product.IProductService;
import com.dowin.util.ParamUtils;
import com.dowin.util.StringUtil;

/**
 * <p>
 * <b>H5Controller</b> is H5页面跳转控制器
 * </p>
 *
 * @since 2019年5月13日
 * @author yangjc
 * @version $Id$
 */
@Controller
@RequestMapping("/h5")
public class H5Controller {

	private Logger logger = Logger.getLogger(H5Controller.class);

	@Autowired
	private MemcacheService memcacheService;
	
	@Autowired
	private Properties appProps;
	
	@Autowired
	private IdemoService demoService;
	
	
	
	/**
	 * 详情入口
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/productDetail")
	public ModelAndView productDetail(HttpServletRequest request, HttpServletResponse response)throws Exception {
		ModelAndView mav = new ModelAndView();
		String channelId = ParamUtils.getParameter(request, "channelId", "");
		String userNo = ParamUtils.getParameter(request, "userNo", "");
		String bizContent = ParamUtils.getParameter(request, "bizContent", "");
		String hidenav = ParamUtils.getParameter(request, "hidenav", "0");
		String productId = ParamUtils.getParameter(request, "productId", "").trim();
		String isicp = ParamUtils.getParameter(request, "isicp", "0").trim();

		//公众号特有参数，用于接收保险公司官方H5
		String salemanCode = ParamUtils.getParameter(request, "salemanCode", "");
	    String unitCode = ParamUtils.getParameter(request, "unitCode", "");
		
		if (StringUtil.isEmpty(userNo)) {
			userNo = "SJ_" + String.valueOf(System.currentTimeMillis());
		}

		logger.info("userNo.........." + userNo);
		String agent = request.getHeader("User-Agent");
		String IsEnvironment = appProps.getProperty("hbx.api.IsEnvironment");
		logger.info("环境类型IsEnvironment="+IsEnvironment);
		
		if (IsEnvironment.equals("true")) {
			hidenav = ParamUtils.getParameter(request, "hidenav", "0");
		}
		
		String tokenId = UuidUtils.getRandomUUID();
		logger.info(String.format("发起的tokenId=%s", tokenId));
		Token token = new Token(userNo, channelId);
		token.setBizContent(bizContent);
		token.setHidenav(hidenav);
		token.setProductId(productId);
		token.setOpenId(null);
		memcacheService.set(tokenId, token, 1000 * 60 * 120);
		Token t = (Token)memcacheService.get(tokenId);
		String decryR5 = RC4Util.decryRC4(t.getBizContent(), "open20160501");

		logger.info(String.format("hbxweb=%s", hbxweb));
		try {
			// 前端提供的H5页面
			String url = "redirect:" + hbxweb + "/ProductDetail?tokenId=" + tokenId + "&hidenav=" + hidenav
					+ "&productId=" + productId + "&isicp=" + isicp;
			mav.setViewName(url);
		} catch (Exception e) {  
			mav.setViewName("/web/h5_error");
			mav.addObject("error_msg", "网络异常！！！");
		}
		return mav;
	}
	
	@RequestMapping(value = "/sayHi", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> sayHi(HttpServletRequest request, HttpServletResponse response) {
		ResultObject result = new ResultObject();
		Map<String, Object> resultMap = new HashMap<String, Object>();//返回结果
		String[] excludeProps = new String[] { "" };// 不需要输出的字段	
		String tokenId = ParamUtils.getParameter(request, "tokenId", "");
		String name = ParamUtils.getParameter(request, "name", "");

		Token token2 = (Token) memcacheService.get(tokenId);

		try {
			String channelId = "";
			String userId = "";
			if (null != token2) {
				channelId = token2.getChannelId();
				userId = token2.getUserId();
			}
			logger.info(String.format("channelId=%s,userId", channelId, userId));

			String orderCode = baseOrderService.getOrderCode();

			String sr = demoService.sayHi(name);
			result = ResponseResultUtil.getResponseResult(Constant.RESULT_CODE_SUCCESS, sr, resultMap);
		} catch (Exception e) {
			logger.error(e, e);
			result = ResponseResultUtil.getResponseResult(Constant.RESULT_CODE_EXCEPTION, "error", resultMap);
		}
		return ResponseUtil.responseEntity(result, excludeProps, lang);
	}


	/**
	 * 我的订单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/orderList")
	public ModelAndView orderList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String channelId = ParamUtils.getParameter(request, "channelId", "");
		String userNo = ParamUtils.getParameter(request, "userNo", "");

		String hbxweb = appProps.getProperty("hbxweb", "");

		String tokenId = UuidUtils.getRandomUUID();
		Token token = new Token(userNo, channelId);
		memcacheService.set(tokenId, token, 1000 * 60 * 120);

		String payurl = String.format("redirect:%s/OrderListOnline?tokenId=%s", hbxweb, tokenId);
		mav.setViewName(payurl);
		return mav;
	}

}